class Sabitler {
  static const Map<int, String> kategoriler = {
    0: "Genel",
    1: "Roman",
    2: "Öykü",
    3: "Eğitim",
    4: "Fantastik",
    5: "Bilim-Kurgu",
    6: "Biyografi",
  };
}